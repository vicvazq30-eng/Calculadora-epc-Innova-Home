import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Calculadora EPC Michael y Nandy",
  description: "Calculadora interna de EPC y comisión para Sunrun",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="es"><body>{children}</body></html>;
}
